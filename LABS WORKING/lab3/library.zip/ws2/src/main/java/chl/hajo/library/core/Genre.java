
package chl.hajo.library.core;

/**
 * The genre of the book
 * @author hajo
 */
//Core model class
public enum Genre {
    THRILLER, NOVEL, ROMANTIC_NOVEL, BIOGRAPHY; 
    
}
