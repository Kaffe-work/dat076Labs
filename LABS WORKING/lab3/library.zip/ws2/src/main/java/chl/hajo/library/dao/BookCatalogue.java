package chl.hajo.library.dao;

import javax.ejb.Stateless;

/**
 * All orders Responsible for putting new PurchaseOrders objects into the model
 *
 * @author hajo
 */
@Stateless
public class BookCatalogue  {

    
    public BookCatalogue() {
       
    }

 
   
}
