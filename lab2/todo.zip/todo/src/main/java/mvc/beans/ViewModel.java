package mvc.beans;

/**
 * Data for JSP pages (an instance of this class i used in the JSP page)
 * 
 * ***  NOTHING TO DO HERE ***
 * 
 * @author hajo
 */

public class ViewModel {
    
    // TODO Supply data to JSP pages
   
   
}
